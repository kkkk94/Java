package java0508;

public class ex01_rename {

	public static void main(String[] args) {
		System.out.println("안녕하세요");
		System.out.println("sysout 입력 후 [ctrl] + [space]");
	}

}
