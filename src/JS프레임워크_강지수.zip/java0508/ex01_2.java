package java0508;

public class ex01_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
