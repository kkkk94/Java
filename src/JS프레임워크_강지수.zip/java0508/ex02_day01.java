/*
 	Date : 2020.05.08 (날짜)
	Author : jisoo (만든사람)
	Description : Java 기본설정 (설명)
	Version : 1.0
 */
package java0508;

public class ex02_day01 {

	public static void main(String[] args) {
		
		String name;
		name = "강지수";
		String birth = "4월27일";
		int age = 27;
		String adr = "인천광역시 연수구 연수동";
		String phone = "010-4221-9128";
		String email = "zgzg0427@naver.com";
		String hobby = "유튜브보기";
		String speciality = "놀기";
		char blood = 'A';
		

		
		System.out.println("제 이름은" + name + "입니다.");
		System.out.println("제 생일은" + birth + "입니다.");
		System.out.println("제 나이는"+ age + "입니다");
		System.out.println("제 주소는"+ adr + "입니다");
		System.out.println("제 핸드폰 번호는"+ phone + "입니다");
		System.out.println("제 이메일주소는"+ email + "입니다.");
		System.out.println("제 취미는"+ hobby +"입니다");
		System.out.println("제 특기는" + speciality + "입니다" );
		System.out.println("제 혈액형은"+blood +"입니다");

		


	}

}
