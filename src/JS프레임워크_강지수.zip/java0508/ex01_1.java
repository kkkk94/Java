package java0508;

public class ex01_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println();
		System.out.println("sysout 입력 후 [ctrl] + [space]");
	}

}
