package java0508;

public class ex02_variableexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
